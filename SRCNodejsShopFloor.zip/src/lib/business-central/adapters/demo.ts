import "server-only";
import { randomUUID } from "crypto";
import type {
  ApiError,
  ApiResult,
  Assignment,
  AssignmentLine,
  LoginResult,
  OperatorRole,
  PostOutputInput,
} from "../types";
import type { ShopFloorService } from "./types";

/**
 * In-memory demo adapter. Mirrors the shape of real BC data (and the real
 * adapter's authorization rules) closely enough that the whole app — login,
 * assignment list, start/stop timer, post output, supervisor cancel — works
 * end to end with BC_MODE=demo and no Business Central tenant at all.
 *
 * Demo credentials are plaintext here on purpose: this is a sandbox, not a
 * security boundary, and must never be reachable when BC_MODE is sandbox or
 * production (service.ts enforces that by construction — see getShopFloorService()).
 */

function delay(ms: number) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function apiError(code: ApiError["code"], message: string): ApiError {
  return { code, message };
}

interface DemoOperator {
  operatorCode: string;
  password: string;
  displayName: string;
  role: OperatorRole;
  mustChangePassword: boolean;
}

const DEMO_OPERATORS: DemoOperator[] = [
  { operatorCode: "RAJU01", password: "demo1234", displayName: "Raju Kumar", role: "Operator", mustChangePassword: false },
  { operatorCode: "SITA01", password: "demo1234", displayName: "Sita Devi", role: "Operator", mustChangePassword: false },
  { operatorCode: "SUP01", password: "demo1234", displayName: "Vikram Singh (Supervisor)", role: "Supervisor", mustChangePassword: false },
];

const demoAssignments = new Map<string, Assignment>([
  [
    "SFA000001",
    {
      number: "SFA000001",
      assemblyOrderNo: "AO-10231",
      itemNo: "BIKE-FRAME-RED",
      description: "Red Frame Bicycle — Model X",
      locationCode: "MAIN",
      assignedOperatorCode: "RAJU01",
      assignedQtyBase: 20,
      postedQtyBase: 0,
      remainingQtyBase: 20,
      status: "Open",
      jobWorkReportNo: "",
      totalElapsedTimeSec: 0,
      lastModifiedAt: new Date().toISOString(),
    },
  ],
  [
    "SFA000002",
    {
      number: "SFA000002",
      assemblyOrderNo: "AO-10245",
      itemNo: "BIKE-FRAME-BLU",
      description: "Blue Frame Bicycle — Model X",
      locationCode: "MAIN",
      assignedOperatorCode: "SITA01",
      assignedQtyBase: 15,
      postedQtyBase: 6,
      remainingQtyBase: 9,
      status: "In Progress",
      jobWorkReportNo: "",
      totalElapsedTimeSec: 5400,
      lastModifiedAt: new Date().toISOString(),
    },
  ],
]);

const demoLines = new Map<string, AssignmentLine[]>([
  [
    "SFA000002",
    [
      {
        assignmentNo: "SFA000002",
        lineNo: 10000,
        postedQtyBase: 6,
        postingReference: "AO-10245-POST1",
        postingDate: new Date().toISOString().slice(0, 10),
        postedByOperatorCode: "SITA01",
        postedAt: new Date().toISOString(),
        isFinalPosting: false,
      },
    ],
  ],
]);

const demoIdempotencyKeys = new Set<string>();

// Demo "sessions": token -> operatorCode. In-memory only, resets on server restart.
const demoSessions = new Map<string, string>();

function findOperator(sessionToken: string): DemoOperator | null {
  const operatorCode = demoSessions.get(sessionToken);
  if (!operatorCode) return null;
  return DEMO_OPERATORS.find((o) => o.operatorCode === operatorCode) ?? null;
}

export const demoAdapter: ShopFloorService = {
  async login(operatorCode, password): Promise<ApiResult<LoginResult>> {
    await delay(300);
    const match = DEMO_OPERATORS.find(
      (op) => op.operatorCode.toLowerCase() === operatorCode.trim().toLowerCase(),
    );
    if (!match || match.password !== password) {
      return { ok: false, error: apiError("UNAUTHORIZED", "Invalid operator code or password.") };
    }
    const sessionToken = randomUUID();
    demoSessions.set(sessionToken, match.operatorCode);
    return {
      ok: true,
      data: {
        operatorCode: match.operatorCode,
        displayName: match.displayName,
        role: match.role,
        mustChangePassword: match.mustChangePassword,
        sessionToken,
      },
    };
  },

  async logout(sessionToken): Promise<ApiResult<void>> {
    demoSessions.delete(sessionToken);
    return { ok: true, data: undefined };
  },

  async getMyAssignments(sessionToken): Promise<ApiResult<Assignment[]>> {
    await delay(250);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    const mine = [...demoAssignments.values()].filter(
      (a) => operator.role !== "Operator" || a.assignedOperatorCode === operator.operatorCode,
    );
    return { ok: true, data: mine };
  },

  async getAssignment(sessionToken, assignmentNo): Promise<ApiResult<Assignment>> {
    await delay(200);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    const assignment = demoAssignments.get(assignmentNo);
    if (!assignment) return { ok: false, error: apiError("NOT_FOUND", "That assignment could not be found.") };
    if (operator.role === "Operator" && assignment.assignedOperatorCode !== operator.operatorCode) {
      return { ok: false, error: apiError("FORBIDDEN", "You are not the assigned operator for this assignment.") };
    }
    return { ok: true, data: assignment };
  },

  async startWork(sessionToken, assignmentNo): Promise<ApiResult<Assignment>> {
    await delay(250);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    const assignment = demoAssignments.get(assignmentNo);
    if (!assignment) return { ok: false, error: apiError("NOT_FOUND", "That assignment could not be found.") };
    if (assignment.assignedOperatorCode !== operator.operatorCode) {
      return { ok: false, error: apiError("FORBIDDEN", "You are not the assigned operator for this assignment.") };
    }
    if (!["Open", "Paused"].includes(assignment.status)) {
      return { ok: false, error: apiError("CONFLICT", `Cannot start work while status is ${assignment.status}.`) };
    }
    assignment.status = "In Progress";
    assignment.lastModifiedAt = new Date().toISOString();
    return { ok: true, data: assignment };
  },

  async stopWork(sessionToken, assignmentNo, pause): Promise<ApiResult<Assignment>> {
    await delay(250);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    const assignment = demoAssignments.get(assignmentNo);
    if (!assignment) return { ok: false, error: apiError("NOT_FOUND", "That assignment could not be found.") };
    if (assignment.assignedOperatorCode !== operator.operatorCode) {
      return { ok: false, error: apiError("FORBIDDEN", "You are not the assigned operator for this assignment.") };
    }
    assignment.totalElapsedTimeSec += 60; // demo: pretend a minute elapsed
    assignment.status = pause ? "Paused" : "Open";
    assignment.lastModifiedAt = new Date().toISOString();
    return { ok: true, data: assignment };
  },

  async postOutput(sessionToken, input: PostOutputInput): Promise<ApiResult<Assignment>> {
    await delay(350);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    const assignment = demoAssignments.get(input.assignmentNo);
    if (!assignment) return { ok: false, error: apiError("NOT_FOUND", "That assignment could not be found.") };
    if (assignment.assignedOperatorCode !== operator.operatorCode) {
      return { ok: false, error: apiError("FORBIDDEN", "You are not the assigned operator for this assignment.") };
    }
    if (demoIdempotencyKeys.has(input.idempotencyKey)) {
      // Duplicate/retried submit: return current state, do not post again.
      return { ok: true, data: assignment };
    }
    if (input.qtyToPostBase <= 0) {
      return { ok: false, error: apiError("VALIDATION_ERROR", "Quantity to post must be greater than zero.") };
    }
    if (input.qtyToPostBase > assignment.remainingQtyBase) {
      return {
        ok: false,
        error: apiError(
          "VALIDATION_ERROR",
          `Quantity to post (${input.qtyToPostBase}) exceeds the remaining assigned quantity (${assignment.remainingQtyBase}).`,
        ),
      };
    }
    demoIdempotencyKeys.add(input.idempotencyKey);
    assignment.postedQtyBase += input.qtyToPostBase;
    assignment.remainingQtyBase -= input.qtyToPostBase;
    const isFinal = input.isFinal || assignment.remainingQtyBase <= 0;
    assignment.status = isFinal ? "Completed" : assignment.status;
    assignment.lastModifiedAt = new Date().toISOString();

    const lines = demoLines.get(input.assignmentNo) ?? [];
    lines.push({
      assignmentNo: input.assignmentNo,
      lineNo: (lines[lines.length - 1]?.lineNo ?? 0) + 10000,
      postedQtyBase: input.qtyToPostBase,
      postingReference: `${assignment.assemblyOrderNo}-DEMO${lines.length + 1}`,
      postingDate: new Date().toISOString().slice(0, 10),
      postedByOperatorCode: operator.operatorCode,
      postedAt: new Date().toISOString(),
      isFinalPosting: isFinal,
    });
    demoLines.set(input.assignmentNo, lines);

    return { ok: true, data: assignment };
  },

  async getAssignmentHistory(sessionToken, assignmentNo): Promise<ApiResult<AssignmentLine[]>> {
    await delay(200);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    return { ok: true, data: demoLines.get(assignmentNo) ?? [] };
  },

  async cancelAssignment(sessionToken, assignmentNo, reason): Promise<ApiResult<Assignment>> {
    await delay(250);
    const operator = findOperator(sessionToken);
    if (!operator) return { ok: false, error: apiError("UNAUTHORIZED", "Your session has expired. Please log in again.") };
    if (operator.role === "Operator") {
      return { ok: false, error: apiError("FORBIDDEN", "Your role does not permit this action.") };
    }
    const assignment = demoAssignments.get(assignmentNo);
    if (!assignment) return { ok: false, error: apiError("NOT_FOUND", "That assignment could not be found.") };
    if (assignment.status === "Completed") {
      return { ok: false, error: apiError("CONFLICT", "This assignment is already completed and cannot be cancelled.") };
    }
    void reason; // demo: not persisted anywhere to show, BC's Audit Log is the real record of this
    assignment.status = "Cancelled";
    assignment.lastModifiedAt = new Date().toISOString();
    return { ok: true, data: assignment };
  },
};
